.. spelling::

    qhull

.. index::
  single: unsorted ; qhull

.. _pkg.qhull:

qhull
=====

-  `Official <https://github.com/qhull/qhull>`__
-  `Hunterized <https://github.com/hunter-packages/qhull>`__
-  `Example <https://github.com/ruslo/hunter/blob/master/examples/qhull/CMakeLists.txt>`__
-  Added by `qhull_developer <https://github.com/t0p4>`__ (`pr-1596 <https://github.com/ruslo/hunter/pull/1596>`__)

.. literalinclude:: /../examples/qhull/CMakeLists.txt
  :language: cmake
  :start-after: # DOCUMENTATION_START {
  :end-before: # DOCUMENTATION_END }
