.. spelling::

  libpcre
  oniguruma
  Regex

Regex
-----

 - :ref:`pkg.libpcre` - Perl-compatible regular expression library
 - :ref:`pkg.oniguruma` - modern and flexible regular expression library
