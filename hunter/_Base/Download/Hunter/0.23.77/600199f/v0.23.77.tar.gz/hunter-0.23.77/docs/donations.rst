.. Copyright (c) 2016, Ruslan Baratov
.. All rights reserved.

Donations
---------

If you like this project and it's goals consider supporting it by making a
donation.

.. image:: https://www.paypalobjects.com/en_US/i/btn/btn_donate_SM.gif
  :target: https://www.paypal.com/cgi-bin/webscr?cmd=_s-xclick&hosted_button_id=UN8PDZZ3Q7VVL
  :alt: PayPal donation

Thanks! :)
