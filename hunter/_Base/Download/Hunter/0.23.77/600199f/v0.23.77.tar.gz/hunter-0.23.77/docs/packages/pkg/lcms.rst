.. spelling::

    lcms

.. index:: unsorted ; lcms

.. _pkg.lcms:

lcms
====

- http://www.littlecms.com/
- `Official GitHub <https://github.com/mm2/Little-CMS>`__
- `Hunterized <https://github.com/hunter-packages/Little-CMS>`__
- `Example <https://github.com/ruslo/hunter/blob/master/examples/lcms/CMakeLists.txt>`__

.. literalinclude:: /../examples/lcms/CMakeLists.txt
  :language: cmake
  :start-after: # DOCUMENTATION_START {
  :end-before: # DOCUMENTATION_END }
