.. spelling::

    pcg

.. index:: random ; pcg

.. _pkg.pcg:

pcg
===

-  `Official <https://github.com/imneme/pcg-c>`__
-  `Hunterized <https://github.com/hunter-packages/pcg-c>`__
-  `Example <https://github.com/ruslo/hunter/blob/master/examples/pcg/CMakeLists.txt>`__
-  Added by `Isaac Hier <https://github.com/isaachier>`__ (`pr-1377 <https://github.com/ruslo/hunter/pull/1377>`__)

.. literalinclude:: /../examples/pcg/CMakeLists.txt
  :language: cmake
  :start-after: # DOCUMENTATION_START {
  :end-before: # DOCUMENTATION_END }
