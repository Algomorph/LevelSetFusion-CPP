.. spelling::

    libxml

.. index:: xml ; libxml2

.. _pkg.libxml2:

libxml2
=======

- http://xmlsoft.org/
- `Example <https://github.com/ruslo/hunter/blob/master/examples/libxml2/CMakeLists.txt>`__

.. literalinclude:: /../examples/libxml2/CMakeLists.txt
  :language: cmake
  :start-after: # DOCUMENTATION_START {
  :end-before: # DOCUMENTATION_END }
