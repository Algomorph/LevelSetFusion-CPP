Compression
-----------

 - :ref:`pkg.BZip2` - high-quality data compressor.
 - :ref:`pkg.lz4` - Extremely Fast Compression algorithm
 - :ref:`pkg.lzma` - A compression library with an API similar to that of zlib.
 - :ref:`pkg.minizip` - enables to extract files from a .zip archive file.
 - :ref:`pkg.szip`
 - :ref:`pkg.ZLIB` - A massively spiffy yet delicately unobtrusive compression library.
