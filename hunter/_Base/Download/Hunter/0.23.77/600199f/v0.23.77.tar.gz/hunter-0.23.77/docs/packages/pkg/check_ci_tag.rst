.. spelling::

    ci

.. index:: cmake_modules ; check_ci_tag

.. _pkg.check_ci_tag:

check_ci_tag
============

-  `Official GitHub <https://github.com/hunter-packages/check_ci_tag>`__
-  `Example <https://github.com/ruslo/hunter/blob/master/examples/check_ci_tag/CMakeLists.txt>`__

.. literalinclude:: /../examples/check_ci_tag/CMakeLists.txt
  :language: cmake
  :start-after: # DOCUMENTATION_START {
  :end-before: # DOCUMENTATION_END }
