.. spelling::

    mkl

.. index::
  single: unsorted ; mkl

.. _pkg.mkl:

mkl
===

-  `Official <https://software.intel.com/mkl>`__
-  `Example <https://github.com/ruslo/hunter/blob/master/examples/mkl/CMakeLists.txt>`__

.. literalinclude:: /../examples/mkl/CMakeLists.txt
  :language: cmake
  :start-after: # DOCUMENTATION_START {
  :end-before: # DOCUMENTATION_END }
