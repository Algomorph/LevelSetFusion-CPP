.. spelling::

    cctz

.. index:: datetime ; cctz

.. _pkg.cctz:

cctz
====

-  `Official <https://github.com/google/cctz>`__
-  `Hunterized <https://github.com/hunter-packages/cctz>`__
-  `Example <https://github.com/ruslo/hunter/blob/master/examples/cctz/CMakeLists.txt>`__
-  Added by `Isaac Hier <https://github.com/isaachier>`__ (`pr-1370 <https://github.com/ruslo/hunter/pull/1370>`__)

.. literalinclude:: /../examples/cctz/CMakeLists.txt
  :language: cmake
  :start-after: # DOCUMENTATION_START {
  :end-before: # DOCUMENTATION_END }
